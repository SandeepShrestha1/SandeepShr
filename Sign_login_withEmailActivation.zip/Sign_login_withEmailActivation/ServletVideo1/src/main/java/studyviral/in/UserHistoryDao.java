
package studyviral.in;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Toyota
 */
public class UserHistoryDao {
    Connection con = MyConnection.getConnection();
    private final RegisterDAO user= new RegisterDAO();
    
    // create record in user history table
    public int createUserHistory(UserHistory userHistory) throws SQLException { 
        System.out.println("hello");
        PreparedStatement stmt = con.prepareStatement(
                "INSERT INTO user_history(user_id, action, detail) VALUES (?,?,?)",
                Statement.RETURN_GENERATED_KEYS
        );
        stmt.setString(1, userHistory.getUser().getEmail());
        stmt.setString(2, userHistory.getAction());
        stmt.setString(3, userHistory.getDetail());
        stmt.executeUpdate();
        ResultSet resSet = stmt.getGeneratedKeys();
        resSet.next();
        return resSet.getInt(1);
    }
}
